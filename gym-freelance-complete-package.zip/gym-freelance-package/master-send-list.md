# Master Outreach List — All 61 Leads (Single Editable File — 57 FL + 4 GA/AL)

Everything in one place, in tracker order, so you can edit directly here before Saturday's send — no need to cross-reference multiple files.

**Legend:** ✅ = confirmed sent already (per your Aug 30 inbox screenshot) — skip these unless following up. ⬜ = not yet sent, ready to go Saturday.

Copy each message as-is, swap in your name, and send via the listed contact. Edit any line directly in this file as needed.

---

### ✅ 1. Elite Body Fitness & Nutrition — Apopka
📧 elitebodyapopka@gmail.com | 📞 (407) 880-2066
> Subject: Your website isn't showing up in Google search
> Hi Mark and Tracey, I came across Elite Body Fitness & Nutrition and wanted to flag something technical: your website is currently set up to block Google from showing it in search results. So even though the site itself looks fine, nobody searching "gym Apopka" or "personal training Apopka" would ever find it there. Given how long you've been established (since 2004!) and how strong your reviews are, that felt worth mentioning. Put together a quick demo of a refreshed version: [demo link]. Happy to help get the technical piece fixed properly too. Let me know if useful. [Your name]

---

### ✅ 2. NUMA Speed Elite — Gainesville
📧 numaeliteoffice@gmail.com | 📞 (352) 262-7573
> Subject: Your website is currently showing a blank page
> Hi there, I was looking into NUMA Speed Elite and tried visiting your website — it's currently showing a completely blank page to visitors. Multiple places that link to you — Yelp, ClassPass, WellnessLiving — all point people to this same broken page. Given NUMA's reputation in Gainesville, that's a real first impression being lost. Put together a quick demo of what a working version could look like: [demo link]. Happy to help get this fixed properly. [Your name]

---

### ✅ 3. Martinez Gym — Palm Bay
📧 Office@martinezgym.fit | 📞 (321) 419-8943
> Subject: Something about the Martinez Gym website
> Hi there, I came across Martinez Gym and read about the story behind it — what a meaningful tribute to Daniel. I noticed the current website is still running on an unedited template, and a few links point to broken or placeholder pages instead of your real content. Given what this gym represents, it felt worth reaching out — a site that actually reflects the story would do it more justice. Put together a quick demo of what an updated version could look like: [demo link]. No pressure at all — just wanted you to know. [Your name]

---

### ✅ 4. Fitness 31 — Titusville
📧 fitness.thirtyone@gmail.com | 📞 (321) 544-6173
> Subject: A website for Fitness 31?
> Hi there, I came across Fitness 31 and love the mission — building a safe, supportive space specifically for women. Noticed there's no website yet though, just Facebook and directory listings. A simple site could help new members find you and get a feel for that mission before their first class. Put together a quick demo of what one could look like: [demo link]. Happy to help if it's useful. [Your name]

---

### ✅ 5. Sarasota Fitness Studio — Sarasota
📧 michael@sarasotafitnessstudio.com | 📞 (941) 894-2596
> Subject: Quick thing on the Sarasota Fitness Studio blog
> Hi Michael, your site is in good shape overall, but I noticed one of your blog posts is still showing its placeholder title — "Blog Post Title Four" — live and public. Easy miss, but worth fixing. Happy to help clean that up, or take a broader look at the site if you're interested: [demo link]. [Your name]

---

### ✅ 6. RC Fitness — Sarasota
📧 rcefitness@gmail.com | 📞 (941) 600-8422
> Subject: A small thing on the RC Fitness website
> Hi RC, I came across RC Fitness and noticed something small but worth mentioning: the social media icons on your website actually link out to generic placeholder pages, not your real Facebook or Instagram. Put together a quick demo of a cleaned-up version: [demo link]. Happy to help fix it up properly if useful. [Your name]

---

### ✅ 7. Sharper Edge Fitness — Daytona Beach
📧 coachmack@sharperedgefitness.org | 📞 (216) 904-5482
> Subject: Sharper Edge's website hasn't caught up to Sharper Edge
> Hi Mack, came across Sharper Edge Fitness — your reviews are excellent. I noticed the website is still the original template from when the gym opened in 2022 though — it doesn't really reflect where things are now. Put together a quick demo of what an updated one could look like: [demo link]. [Your name]

---

### ✅ 8. Healthy Harts Fitness — Ocala
📧 info@healthyhartsfitness.com | 📞 (352) 351-3100
> Subject: A technical issue with your website (not visible, but real)
> Hi Clint, I was looking at Healthy Harts Fitness's website and noticed something most people wouldn't catch: it's currently configured to block search engines from indexing it. Even if someone searches "personal training Ocala," your site can't show up in results. Happy to point you to exactly what's causing it, or help get it fixed properly. Also put together a quick demo of an updated version, if useful: [demo link]. [Your name]

---

### ✅ 9. Wood's Family Fitness — Live Oak
📧 woodsfamilyfitness@gmail.com | 📞 (386) 330-0363
> Subject: A website for Wood's Family Fitness
> Hi David & Rhonda, I read the piece about Wood's Family Fitness and the story behind taking over the gym — it's clear how much care you've put into it, and being the only Silver Sneakers provider in Live Oak is a real distinction worth highlighting. I noticed you don't have a website yet. Put together a quick demo: [demo link]. [Your name]

---

### ✅ 10. Gordon Extreme Fitness — Palatka
📞 (386) 530-3195 — ⚠️ **email bounces (inbox full) — call instead, don't re-email**
> "Hi Rudy, came across Gordon Extreme Fitness — your reviews are great, people clearly stick around for years. Noticed you don't have a website. Put together a quick demo of what a simple one could look like: [demo link]." (use this as a phone script)

---

### ✅ 11. New Flex Gym & Fitness Center — Clewiston
📧 newflex341@gmail.com | 📞 (863) 983-9494
> Subject: Website for New Flex Gym while you're still growing
> Hi there, saw New Flex Gym on Facebook/Instagram — looks like a great new spot in Clewiston. A simple website could help new folks find you when they search "gym Clewiston." Quick demo here: [demo link]. [Your name]

---

### ✅ 12. Downtown Athletic Club — Arcadia
📧 bphdac415@yahoo.com | 📞 (863) 494-6799
> Subject: A website for Downtown Athletic Club
> Hi Bradley, I've seen how well-loved Downtown Athletic Club is in Arcadia — 98% recommend on Yelp is no small thing. Put together a quick demo of what one could look like: [demo link]. [Your name]

---

### ⬜ 13. Evolve Fitness Tampa — Tampa
📞 No email — Facebook message or visit
> Subject: Quick thing I noticed about Evolve Fitness Tampa
> Hi Milly & Travis, I was looking at gyms around Midtown Tampa and noticed Evolve doesn't have its own website yet. Your reviews are excellent, but anyone searching "personal training Midtown Tampa" right now probably isn't finding you. Put together a quick demo: [demo link]. [Your name]

---

### ⬜ 14. A+ Fitness — Sebring
📧 aplusfitness1@gmail.com | 📞 (863) 441-2327
> Subject: 13 years in business — website worth a look?
> Hi Aaron, I came across A+ Fitness — noticed you've been training people one-on-one since 2012, but no website. Put together a quick demo: [demo link]. [Your name]

---

### ⬜ 15. The Spot Fitness Studio — Winter Haven
📞 No email — Instagram DM or Facebook
> Subject: A home base for The Spot, beyond Instagram
> Hi Anayah, love what you've built at The Spot. Noticed you don't have your own website though. Mocked up a quick demo: [demo link]. [Your name]

---

### ⬜ 16. Roth Allen Fitness — DeLand
📞 No email — Facebook message
> Subject: Website for Roth Allen Fitness?
> Hi Roth, noticed Roth Allen Fitness doesn't have a website — just Facebook. Put together a quick demo: [demo link]. [Your name]

---

### ⬜ 17. RetroFlex Fitness — Zephyrhills/Dade City
📧 Retroflexfitness@yahoo.com | 📞 (813) 782-3539
> Subject: RetroFlex Fitness — 387 reviews, no website?
> Hi there, I came across RetroFlex — nearly 400 reviews, all glowing, two locations, zero web presence outside Facebook. Quick demo here: [demo link]. [Your name]

---

### ⬜ 18. The DAM Gym — LaBelle
📞 (863) 674-1122 — no email
> Subject: New ownership, new website?
> Hi Dana, saw The DAM Gym took over from Big Iron Barbell this year. Since you're already rebuilding the brand, this seemed like the right moment to mention: no website yet. Quick demo: [demo link]. [Your name]

---

### ⬜ 19. Elite Squad Gym — Fort Myers
📞 (239) 333-8494 — no email; Instagram @elitesquadgym
> Hi Janski — came across Elite Squad Gym. Impressive track record (1,000+ clients, 10+ years) but what shows up online right now is just a free Google placeholder page. Put together a quick demo: [demo link].

---

### ⬜ 20. Panama City Collective Fitness — Panama City
📧 Panamacitycrossfit@gmail.com | 📞 (850) 640-1194
> Subject: A few loose ends from your rebrand
> Hi there, noticed Panama City Collective Fitness's website still has a few leftover pieces from the old "Panama City CrossFit" name. Quick demo of a fully updated version: [demo link]. [Your name]

---

### ⬜ 21. Odin Fitness — Naples
📞 (239) 331-7727 — no email; Instagram @odin_fitness
> Hi — saw Odin Fitness has new ownership and members are loving the upgrades. Noticed there's no website yet. Quick demo: [demo link].

---

### ⬜ 22. Live Well Fitness Center — Fort Pierce
📧 Livewellfitness5@gmail.com | 📞 (772) 807-0414 — ⚠️ confirm still open (Sunbiz shows dissolved)
> Subject: A website for Live Well Fitness Center
> Hi Nicholas, came across Live Well Fitness Center — the 5-week challenge results are great. Noticed no website. Quick demo: [demo link]. [Your name]

---

### ⬜ 23. Debs Gym — Lakeland
📞 (863) 683-9300 — no email
> Hi Debbie — came across Debs Gym: House of Perfection. Noticed the website's copyright footer still says 2016. Quick demo: [demo link].

---

### ⬜ 24. DeLand Fitness Studio — DeLand
📞 Butch (386) 717-5822 / Max (386) 402-6982 — no email
> Hi — came across DeLand Fitness Studio. Small thing I noticed: your website's browser tab still shows the default "Mysite" title. Happy to help polish that up: [demo link].

---

### ⬜ 25. Hammer Time Fitness — New Port Richey
📞 (727) 916-1655 — no email
> Hi Mark and Christine — came across Hammer Time Fitness. Noticed your website's copyright footer still says 2009. Quick demo: [demo link].

---

### ⬜ 26. Strive Athletic Club — Wesley Chapel
📞 (813) 428-6973 — no email — ⚠️ CONFIRM STILL OPEN FIRST (mixed signals, see tracker notes)
> Hi John — I tried visiting Strive Athletic Club's website and it's showing a "reactivate your account" message instead of your actual site. Quick demo: [demo link].

---

### ⬜ 27. Iron Anchor Gym — Leesburg
📍 No phone/email — address: 10601 US-441 Ste C5, Leesburg, FL 34788. Try in-person visit or local FB group message.

---

### ⬜ 28. CTX Barbell — Longwood
📞 (407) 575-9377 — no email; Instagram @ctxbarbellorlando
> Hi — came across CTX Barbell, impressive equipment lineup for serious powerlifters. Noticed no website. Quick demo: [demo link].

---

### ⬜ 29. Elite FitClub — Haines City
📞 (863) 204-9663 — no email
> Hi Saray — heard about Elite FitClub starting from your garage. Noticed there's no website yet. Quick demo: [demo link].

---

### ⬜ 30. Prime Performance Club — Wildwood
📧 Primeperformanceclub@outlook.com | 📞 (352) 303-8984
> Subject: A website for Prime Performance Club?
> Hi — congrats on the new facility! Noticed there's no website yet, just Facebook/Instagram and an unclaimed WellnessLiving listing. Put together a quick demo of what one could look like: [demo link]. Would help new clients in the Wildwood/Villages area find you as you're getting started. Happy to chat if useful. [Your name]

---

### ⬜ 31. Body By DJ Studios — Dunedin
📞 (727) 282-7561 — no email; Instagram or TeamUp booking page
> Subject: A website for Body By DJ Studios?
> Hi Derrick — came across Body By DJ Studios in downtown Dunedin. Noticed there's no dedicated website, just a booking page and Instagram. Put together a quick demo of what one could look like: [demo link]. Happy to chat if useful.

---

### ⬜ 32. Champion Fitness — Madison
📞 (850) 779-7280 — no email
> Subject: A website for Champion Fitness?
> Hi Chase — came across Champion Fitness in Madison. Noticed there's no dedicated website, just Facebook and a few directory listings. With yoga, spin, and kids' karate on offer, a simple site could help new families find you before ever walking in. Quick demo: [demo link]. Happy to chat if useful.

---

### ⬜ 33. Barnyard Community Fitness — Perry
📞 (386) 249-1202 / (850) 843-4182 — no email
> Subject: A website for Barnyard Community Fitness?
> Hi there — came across Barnyard Community Fitness in Perry, love the "no egos, just hard work" community vibe. Noticed there's no dedicated website, just Facebook/Instagram. Quick demo of what one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 34. North Florida Fitness — Starke
📞 (904) 454-1471 — no email
> Subject: A website for North Florida Fitness?
> Hi there — came across North Florida Fitness, newly opened in Starke. Noticed there's no dedicated website, just Facebook/Instagram and a signup portal. Quick demo of what one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 35. S&J Downtown Athletic Club — Starke
📞 (904) 214-6110 — no email
> Subject: A website for S&J Downtown Athletic Club?
> Hi there — came across S&J Downtown Athletic Club, 24/7 gym in Starke. Noticed there's no real website, just a free Google placeholder page. Quick demo of what a real one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 36. Union Family Fitness — Lake Butler
📞 (386) 433-0451 — no email
> Subject: A website for Union Family Fitness?
> Hi there — came across Union Family Fitness in Lake Butler. Noticed there's no dedicated website, just Instagram/Facebook. Quick demo of what one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 37. Forward Fitness — Cross City
📧 forwardfitnessstudio@gmail.com | 📞 (352) 356-0304
> Subject: A website for Forward Fitness?
> Hi Karen — came across Forward Fitness, a great women's fitness studio in Cross City. Noticed there's no dedicated website, just Facebook and a WellnessLiving listing. Quick demo of what one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 38. Neighborhood Fitness — Chipley
📞 (850) 209-7153 — no email
> Subject: A website for Neighborhood Fitness?
> Hi there — came across Neighborhood Fitness in Chipley. Noticed there's no dedicated website, just Facebook and a membership portal. Put together a quick demo of what one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 39. #GymLife — Blountstown
📞 (850) 508-3534 — no email
> Subject: A website for #GymLife?
> Hi there — came across #GymLife in Blountstown, love that you've got a kids' playroom and a racquetball court alongside the gym. Noticed there's no real website — the domain on your Chamber listing actually points to an unrelated clothing brand. Put together a quick demo of a real one: [demo link]. Happy to help if useful.

---

### ⬜ 40. B Fitness Monticello — Monticello
📞 (850) 332-1551 — no email — owner referenced as "Joe" in reviews
> Subject: A website for B Fitness?
> Hi Joe — came across B Fitness in Monticello, sounds like a great community spot. Noticed there's no website, just social media. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 41. THE GYM / Kickin It Fitness — Defuniak Springs
📍 No phone/email found — recommend in-person visit or Facebook search for "Kickin It Fitness Defuniak Springs"
> Military-owned, boxing/kickboxing/dance/yoga studio led by Stephen "Murph" Murphy. No demo message drafted yet — no contact channel confirmed.

---

### ⬜ 42. Down Range Fitness — Bristol
📞 (850) 545-2788 — no email — new owner Samantha Buckhalt (took over from father Sidney Johnson)
> Subject: Congrats on Down Range Fitness!
> Hi Samantha — congrats on taking over Down Range Fitness! Since you're already updating equipment, this seemed like a good time to mention: there's no website yet, just Facebook. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 43. 180 Fitness — Bristol
📞 (850) 643-2144 — no email
> Subject: A website for 180 Fitness?
> Hi there — came across 180 Fitness in Bristol, sounds like a great low-key spot to train. Noticed there's no website. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 44. Garcia's Boxing Gym — Clewiston
📞 (231) 342-7552 — no email
> Subject: A website for Garcia's Boxing Gym?
> Hi there — came across Garcia's Boxing Gym in Clewiston. Noticed there's no real website, just a directory listing. Put together a quick demo: [demo link]. Would help families searching for a boxing program for their kids find you more easily. Happy to help if useful.

---

### ⬜ 45. Country Strong Gym — Mayo
📧 thecountrystronggymmayo@gmail.com | 📞 (386) 854-0115 — owner Melissa
> Subject: A website for Country Strong Gym?
> Hi Melissa — came across Country Strong Gym in Mayo, love that you offer 20+ classes and such a welcoming atmosphere. Noticed there's no real website yet, just Facebook. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 46. Dicks Power House — Live Oak
📞 (386) 623-9098 — no email
> Subject: A website for Dicks Power House?
> Hi there — came across Dicks Power House in Live Oak, sounds like a great 24/7 spot. Noticed there's no real website, just Facebook and the membership portal. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 47. Gladiator Fitness — Crescent City
📧 elitedaniel2017@gmail.com | 📞 (386) 698-2533 — owner Daniel Aragon
> Subject: A small thing on the Gladiator Fitness website
> Hi Daniel — came across Gladiator Fitness. Noticed your site's team section still has the placeholder text from the template ("Describe the team member here...") rather than real bios. Easy thing to miss, but worth fixing since it's the first thing new visitors see. Put together a quick demo of a cleaned-up version: [demo link]. Happy to help if useful.

---

### ⬜ 48. The Elite Gym LLC — Bunnell
📞 (386) 597-3016 — no email — owner Shelby
> Subject: A website for The Elite Gym?
> Hi Shelby — came across The Elite Gym in Bunnell, love the "Exclusive. Pristine. Elite." positioning. Noticed there's no website yet, just Facebook. A simple site could reinforce that same exclusive feel before someone even walks in. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 49. The SweatBox Gym — Fort Meade
📞 (863) 205-1262 — no email — owner Pastor Andrea Camp
> Subject: A website for The SweatBox Gym?
> Hi Pastor Camp — came across The SweatBox Gym in downtown Fort Meade. Noticed there's no real website for the actual gym here (there's a similarly-named one in Indiana, but that's a different business). Put together a quick demo of what a real one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 50. The Monster Factory — Lake Placid
📞 (863) 275-0615 — no email — Sensei Jose Laguer
> Subject: A website for The Monster Factory?
> Hi Sensei Laguer — read about The Monster Factory's move to the new location and the story behind it, it's clear how much heart goes into what you and Melissa have built. Noticed there's no website yet, just Facebook. Put together a quick demo of what one could look like: [demo link]. Happy to help if useful.

---

### ⬜ 51. Kommunity Box Fit — Pahokee
📞 (561) 692-1506 — no email
> Subject: A website for Kommunity Box Fit?
> Hi there — came across Kommunity Box Fit in Pahokee. Noticed there's no real website (even the Facebook page is hard to find/view right now). Put together a quick demo: [demo link]. Would help families in Pahokee find you more easily. Happy to help if useful.

---

### ⬜ 52. The Refinery Fitness — Palatka
📧 refineryfitness@yahoo.com | 📞 (386) 937-2358 — owner Dina
⚠️ Birdeye lists as "temporarily closed" but site looks active — confirm before contacting
> Subject: Your website is invisible to Google search
> Hi Dina — I came across The Refinery Fitness and love the concept. I checked your website and noticed it's currently configured to block search engines from indexing it — nobody searching "personal training Palatka" would find it in Google results. Happy to point you to exactly what's causing it, or help fix it. Quick demo of an updated version: [demo link]. No pressure — just thought you'd want to know.

---

### ⬜ 53. Nomads Martial Arts — Melrose
📞 (352) 478-5115 — no email
> Subject: A couple things on the Nomads Martial Arts website
> Hi there — came across Nomads Martial Arts. Noticed the website's About section still shows the placeholder text from the template ("Click to edit and tell your visitors more..."), and the copyright footer says 2018. Easy things to miss, but worth fixing since they're the first thing new visitors see. Put together a quick demo of a cleaned-up version: [demo link]. Happy to help if useful.

---

### ⬜ 54. Warehouse Gym — High Springs
📞 (386) 418-8161 — no email — owners Bill & Steve
> Subject: A website for Warehouse Gym?
> Hi Bill/Steve — came across Warehouse Gym in High Springs. Noticed there's no real website, just Facebook and some directory listings. Put together a quick demo: [demo link]. Would give people an easy way to see your hours and info without needing to call. Happy to help if useful.

---

### ⬜ 55. 8 Limbs MMA — Fort White
📞 (954) 806-3358 — no email
> Subject: A website for 8 Limbs MMA?
> Hi there — came across 8 Limbs MMA in Fort White. Noticed there's no website of your own — every search result actually points to unrelated gyms with the same name in other states. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 56. Elevate Fitness — Eustis
📧 elevatefitnessfl@gmail.com | 📞 (321) 304-7011 — owners Andrea & David Iturrino
> Subject: Your website is currently showing a blank page
> Hi Andrea and David — I came across Elevate Fitness and tried visiting your website — it's currently showing a completely blank page with no content at all. Put together a quick demo of what a working version could look like: [demo link]. Happy to help get this fixed properly.

---

### ⬜ 57. Elevated Athletics — Groveland
📞 (407) 252-7070 — no email
> Subject: A website for Elevated Athletics?
> Hi there — came across Elevated Athletics in Groveland. Noticed there's no website, just Facebook. Put together a quick demo: [demo link]. Would help parents researching cheer/tumble programs find you more easily. Happy to help if useful.

---

### ⬜ 58. 1ElevenFitness — Bainbridge, GA
📞 (949) 426-2562 — no email — owner Philip Dollar
> Subject: A website for 1ElevenFitness?
> Hi Philip — came across 1ElevenFitness in downtown Bainbridge. Noticed there's no real website, just Facebook and a booking link. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 59. USA Gym & Fitness Center — Andalusia, AL
📞 (334) 222-5828 — no email — owner Darrell Barnett
> Subject: A website for USA Gym & Fitness Center?
> Hi Darrell — came across USA Gym & Fitness Center. Nearly 30 years in business across two locations, but noticed there's no real website. Put together a quick demo: [demo link]. Happy to help if useful.

---

### ⬜ 60. USA Gym & Fitness Center (Opp) — Opp, AL
📞 (334) 493-1212 — no email
⚠️ Different location from the Andalusia USA Gym already listed — same brand, separate address/phone
> Subject: A website for USA Gym & Fitness Center?
> Hi there — I noticed a few reviews asking if there's a website to sign up on, since the current contact info isn't working reliably. Put together a quick demo: [demo link]. Would solve exactly what those reviews are asking for. Happy to help if useful.

---

### ⬜ 61. Dillards Elite Fitness LLC — Opp, AL
📞 (334) 378-8735 — no email
> Subject: A website for Dillards Elite Fitness?
> Hi there — came across Dillards Elite Fitness in Opp. Noticed there's no real website, just a Facebook page. Put together a quick demo: [demo link]. Happy to help if useful.
