# Complete Outreach & Analysis — All Leads, One Document

**Already sent (per your Aug 30 inbox):** Elite Body Fitness & Nutrition, NUMA Speed Elite, Martinez Gym, Fitness 31, Sarasota Fitness Studio, RC Fitness, Sharper Edge Fitness, Healthy Harts Fitness, Wood's Family Fitness, Gordon Extreme Fitness, New Flex Gym & Fitness Center, Downtown Athletic Club — these appear in the sections below too (for reference/follow-up), but you can skip past them for now.

**Everything else below is unsent and ready to go**, in the order it was found. Each entry has: the problem, the story/context, the pitch angle, contact info, and a ready-to-send message.

---




All 10 confirmed to have no real website (Facebook/Instagram/third-party booking pages only). Demo sites are built and linked at the bottom of each entry.

**Email address status — read before sending anything:**
| Business | Email | Source |
|---|---|---|
| Evolve Fitness Tampa | Not found | — |
| A+ Fitness | aplusfitness1@gmail.com | Confirmed on Facebook page |
| The Spot Fitness Studio | Not found | — |
| Roth Allen Fitness | Not found | — |
| RetroFlex Fitness | Retroflexfitness@yahoo.com | Confirmed on Facebook page |
| Downtown Athletic Club | bphdac415@yahoo.com | Confirmed on Facebook page |
| New Flex Gym & Fitness Center | newflex341@gmail.com | Confirmed on Facebook/Instagram |
| The DAM Gym | Not found | — |
| Gordon Extreme Fitness | gordonextremefitness@gmail.com | Confirmed on Facebook page |
| Wood's Family Fitness | woodsfamilyfitness@gmail.com | Confirmed on Facebook page |

For the 6 with no email: your best paths are Facebook Page Message (all 6 have active pages), or the phone numbers listed below. I'd rather send you to the right channel than hand you a fabricated address that bounces.

---

## 1. Evolve Fitness Tampa (Tampa) — Milly & Travis
**Read:** Small, 2-owner semi-private studio, ~15 Google reviews, clearly early-stage (opened recently, still building presence). Loyal existing clients (5-year training relationships mentioned in reviews) but zero web presence beyond Facebook.
**Approach:** Low pressure, "I noticed you don't have a site yet" angle works well here — they're small enough that a missing website reads as an oversight, not a choice. Emphasize how a site helps them look as established as their client loyalty suggests.
**Best contact path:** Facebook page message or in-person visit (studio is walk-in friendly).

**Email:**
> **Subject:** Quick thing I noticed about Evolve Fitness Tampa
>
> Hi Milly & Travis,
>
> I was looking at gyms around Midtown Tampa and noticed Evolve doesn't have its own website yet — just the Facebook page. Your reviews are excellent (people training with you for years!), but anyone searching "personal training Midtown Tampa" right now probably isn't finding you.
>
> I put together a quick demo of what a simple one-page site could look like for Evolve: [demo link]
>
> No obligation — just wanted you to see it. If it's useful, I'd love to help you get something like this live. Happy to chat whenever works.
>
> [Your name]

---

## 2. A+ Fitness (Sebring) — Aaron Lundquist
**Read:** 13 years in business, one-on-one only, clearly established and trusted (client testimonials mention adapting to physical limitations). Longevity + no website is the strongest possible contrast to lead with.
**Approach:** Lead with the longevity fact directly — "you've been open 13 years and don't have a website" is a compelling, respectful hook. This isn't a new business testing the waters; it's a proven one that's been overlooked online.
**Best contact path:** Email (aplusfitness1@gmail.com, confirmed on their Facebook page) or call (863) 441-2327.

**Email:**
> **Subject:** 13 years in business — website worth a look?
>
> Hi Aaron,
>
> I came across A+ Fitness while looking into Sebring gyms — noticed you've been training people one-on-one since 2012, but you don't have a website, just a Facebook page.
>
> That seems like a missed opportunity given how long you've been established. I put together a quick demo of what a simple site could look like: [demo link]
>
> Would take the guesswork out for anyone searching "personal trainer Sebring FL" who hasn't heard of you by word of mouth yet. Happy to talk through it if you're interested.
>
> [Your name]

---

## 3. The Spot Fitness Studio (Winter Haven) — Anayah Lawrence
**Read:** Boutique, personality-driven (owner is also the main instructor/choreographer per reviews). Younger brand energy — dance/cardio classes, social-media-native.
**Approach:** Lean into the personal-brand angle. A site here should function like a booking/schedule hub, not a hard sell — she's likely Instagram-fluent already, so frame the site as "a home base that isn't rented from Facebook."
**Best contact path:** Instagram DM or Facebook message — she's active there.

**Email:**
> **Subject:** A home base for The Spot, beyond Instagram
>
> Hi Anayah,
>
> Love what you've built at The Spot — the energy in your reviews is real. I noticed you don't have your own website though, just Facebook/Instagram.
>
> A simple site could give new clients a place to see your class schedule and book, without depending on social media algorithms to find you. I mocked up a quick demo: [demo link]
>
> If it's not for you, no worries at all — just thought it was worth showing you.
>
> [Your name]

---

## 4. Roth Allen Fitness (DeLand) — Roth Allen
**Read:** Solo trainer, name-brand business (his own name), Facebook-only. Reviews mention military-focused conditioning work (Florida National Guard client).
**Approach:** Solo trainers often don't prioritize marketing infrastructure — direct and practical framing works best. Keep it short.
**Best contact path:** Facebook message.

**Email:**
> **Subject:** Website for Roth Allen Fitness?
>
> Hi Roth,
>
> Noticed Roth Allen Fitness doesn't have a website — just Facebook. For a name-brand training business like yours, a simple site can help people find and trust you before they even reach out.
>
> Put together a quick demo here: [demo link]
>
> Let me know if you'd want something like this built out for real.
>
> [Your name]

---

## 5. RetroFlex Fitness (Zephyrhills / Dade City) — owners unnamed
**Read:** Two locations, ~387 Facebook reviews, 100% recommend — this is a serious, well-loved local operation punching above its digital weight. No named owner found; address generically to "the RetroFlex team."
**Approach:** Multi-location + huge review count + no site is a strong "you've outgrown Facebook-only" pitch. Worth a phone call given the scale.
**Best contact path:** Call (813) 782-3539, or Facebook message.

**Email:**
> **Subject:** RetroFlex Fitness — 387 reviews, no website?
>
> Hi there,
>
> I came across RetroFlex on Facebook — nearly 400 reviews, all glowing, two locations. That's a lot of trust built up with zero web presence outside Facebook.
>
> A simple website would give both locations one place to point new members, and help you show up when people search "gym Zephyrhills" or "gym Dade City." Quick demo here: [demo link]
>
> Happy to talk whenever's convenient.
>
> [Your name]

---

## 6. Downtown Athletic Club (Arcadia) — Bradley
**Read:** No-contract, small-town gym, 98% recommend, owner known by name in reviews ("Bradley is a friendly owner"). Classic small-town operator — likely not thinking about web presence at all.
**Approach:** Community/small-town framing. Keep it warm and low-pressure — this crowd responds better to relationship framing than "you're losing business" framing.
**Best contact path:** Call (863) 494-6799 or in person — Arcadia is small enough that a visit could work well.

**Email:**
> **Subject:** A website for Downtown Athletic Club
>
> Hi Bradley,
>
> I've seen how well-loved Downtown Athletic Club is in Arcadia — 98% recommend on Yelp is no small thing. I noticed you don't have a website though.
>
> Put together a quick demo of what one could look like: [demo link]
>
> No pressure either way — just thought a gym this well-regarded deserved a proper home online. Let me know if you'd like to chat.
>
> [Your name]

---

## 7. New Flex Gym & Fitness Center (Clewiston) — owner unnamed
**Read:** "Opening soon" energy in some listings, younger/newer operation, iron-focused branding. No reviews yet on some platforms — could be genuinely new.
**Approach:** Because it may be newly opened, frame this as "get ahead of it now" rather than "you've been missing this" — different psychology for a new business vs. an established one.
**Best contact path:** Facebook message (newflex341@gmail.com) or Instagram.

**Email:**
> **Subject:** Website for New Flex Gym while you're still growing
>
> Hi there,
>
> Saw New Flex Gym on Facebook/Instagram — looks like a great new spot in Clewiston. Since you're still building your member base, a simple website could help new folks find you when they search "gym Clewiston" — right now that's Facebook-only.
>
> Quick demo here: [demo link]
>
> Happy to help if useful.
>
> [Your name]

---

## 8. The DAM Gym (LaBelle) — Dana Morgan
**Read:** Rebranded January 2025 from "Big Iron Barbell" — new ownership, actively repositioning the business. This is the single best-timed pitch in the batch: new owners rebuilding brand identity are the most receptive to a new website.
**Approach:** Lead directly with the rebrand — "you're already updating everything else, a website is the natural next step."
**Best contact path:** Call (863) 674-1122.

**Email:**
> **Subject:** New ownership, new website?
>
> Hi Dana,
>
> Saw The DAM Gym took over from Big Iron Barbell this year — congrats on the new chapter. Since you're already rebuilding the brand, this seemed like the right moment to mention: you don't have a website yet, just Facebook/Instagram.
>
> Put together a quick demo of what one could look like for the new DAM Gym: [demo link]
>
> Would love to help make sure LaBelle finds the new version of the gym easily. Let me know your thoughts.
>
> [Your name]

---

## 9. Gordon Extreme Fitness (Palatka) — Rudy Gordon
**Read:** Solo trainer/owner, personal brand ("Rudy Gordon, the owner and trainer"), small space, loyal long-term clients (3-year relationships mentioned).
**Approach:** Similar to Roth Allen — solo operator, keep it direct and practical.
**Best contact path:** Email (gordonextremefitness@gmail.com) or call (386) 530-3195.

**Email:**
> **Subject:** Website for Gordon Extreme Fitness?
>
> Hi Rudy,
>
> Came across Gordon Extreme Fitness on Facebook — your reviews are great, people clearly stick around for years. Noticed you don't have a website though.
>
> Quick demo of what a simple one could look like: [demo link]
>
> Would help new folks in Palatka find you online before they ever see the Facebook page. Let me know if you'd like to talk it through.
>
> [Your name]

---

## 10. Wood's Family Fitness (Live Oak) — David & Rhonda Wood
**Read:** The richest story in the batch — took over an existing gym, family business, only Silver Sneakers provider in town, explicitly community/faith-driven per a local news writeup. A local news article already confirmed "online sign-ups are not available" — direct confirmation of the gap.
**Approach:** This is the warmest lead of the ten — use the community/family angle heavily, and reference specifics (only Silver Sneakers provider, family-run) to show you did real homework, not a form letter.
**Best contact path:** Call (386) 330-0363 or email woodsfamilyfitness@gmail.com (confirmed on Facebook) — this is a relationship-first crowd.

**Email:**
> **Subject:** A website for Wood's Family Fitness
>
> Hi David & Rhonda,
>
> I read the piece about Wood's Family Fitness and the story behind taking over the gym — it's clear how much care you've put into it, and being the only Silver Sneakers provider in Live Oak is a real distinction worth highlighting.
>
> I noticed you don't have a website yet, so new folks in town have no easy way to find you online before walking in. Put together a quick demo: [demo link]
>
> No pressure at all — just wanted you to see what's possible. Happy to talk whenever works for you.
>
> [Your name]

---

## Suggested outreach order (highest response likelihood first)
1. **The DAM Gym** — new ownership = highest receptivity to change right now
2. **Wood's Family Fitness** — richest personal story, easiest to make it feel human not spammy
3. **A+ Fitness** — 13-year track record makes the "gap" most striking
4. **Downtown Athletic Club** — small-town, named owner, warm framing works
5. **RetroFlex Fitness** — biggest potential win (2 locations, huge review base)
6. Remaining six — solo trainers and newer spots — good volume plays, lower individual urgency

---

# Phase 2 — Bad/Outdated Websites (not missing, just neglected)

Different pitch angle for this batch: they *do* have a website, but it's actively hurting them — technically broken, visually stuck in the past, or outsourced to a placeholder they don't control. The email framing should show you actually looked at their site, not just noticed its absence.

## 11. Healthy Harts Fitness (Ocala) — Clint Hart (owner, retired NFL player)
**The problem:** They have a real, decent-looking WordPress site (built in 2025 by an agency) — but it's set to `noindex, nofollow` in its metadata. That means Google is explicitly blocked from indexing it. No matter how good their business is, **they cannot be found via Google search at all.** This is invisible to a non-technical owner — the site looks fine when you visit it directly, so nobody would know to check.
**Approach:** This is a technical-credibility pitch, not a design pitch. Frame it as "I noticed something behind the scenes" — this positions you as someone who actually understands web infrastructure, not just aesthetics. High-trust angle for a business owner who already paid an agency once and may be wary of being oversold again.
**Contact:** info@healthyhartsfitness.com or (352) 351-3100

**Email:**
> **Subject:** A technical issue with your website (not visible, but real)
>
> Hi Clint,
>
> I was looking at Healthy Harts Fitness's website and noticed something most people wouldn't catch: it's currently configured to block search engines from indexing it. In plain terms — even if someone searches "personal training Ocala," your site can't show up in the results. It's a setting issue, not a content issue, but it likely means you're not getting the search traffic the site was built for.
>
> Happy to point you to exactly what's causing it, or help get it fixed properly. Also put together a quick demo of an updated version, if useful: [demo link]
>
> No pressure — just thought you'd want to know.
>
> [Your name]

---

## 12. Sharper Edge Fitness (Daytona Beach) — Mack Mikulski (owner)
**The problem:** Real domain (sharperedgefitness.org), but it's an untouched free Wix template from 2022 — leftover iPhone photo filenames as image captions, broken spacing artifacts, no real booking system (redirects out to a third-party Vagaro page), copyright footer still reads "©2022." This is the clearest "abandoned after initial setup" site in the batch.
**Approach:** Faith/mission-driven branding ("mission-minded... physical, mental, and spiritual health") — keep tone respectful and values-aligned, not salesy. Emphasize that the site doesn't reflect how far the gym has come since 2022 (65+ reviews, established community) — the site is stuck in launch-day mode while the business has grown past it.
**Contact:** coachmack@sharperedgefitness.org or (216) 904-5482

**Email:**
> **Subject:** Sharper Edge's website hasn't caught up to Sharper Edge
>
> Hi Mack,
>
> Came across Sharper Edge Fitness — your reviews are excellent, and it's clear you've built something real in Daytona Beach. I noticed the website is still the original template from when the gym opened in 2022, though — it doesn't really reflect where things are now.
>
> Put together a quick demo of what an updated one could look like: [demo link]
>
> Would love to help make sure the site matches the gym people are actually walking into these days. Let me know your thoughts.
>
> [Your name]

---

## 13. Elite Squad Gym (Fort Myers) — Janski Carran (owner/trainer)
**The problem:** No real website at all — what shows up is a free auto-generated Google Business Site (a placeholder page Google creates automatically, not something Carran built or controls). It's the digital equivalent of a business card generated by a directory, not a real site.
**Approach:** Solo trainer, home-gym-based, 1,000+ clients over 10 years — strong track record, weak online presence. Straightforward, practical framing works.
**Contact:** (239) 333-8494 — no email found; recommend Instagram DM (@elitesquadgym) or call.

**Email (for Instagram/text, given no email found):**
> Hi Janski — came across Elite Squad Gym. Impressive track record (1,000+ clients, 10+ years) but what shows up online right now is just a free Google placeholder page, not a real site. Put together a quick demo of what one could look like: [demo link]. No pressure, just thought you'd want to see it.

---

## Phase 2 pattern worth noting
All three of these have one thing in common: **the business is doing well, but the website hasn't been touched since it was first set up** (or, in one case, hasn't been checked at all technically). That's a different — arguably easier — pitch than "you have no website": you're not asking them to take a leap into something new, you're pointing out something that's already broken or stagnant on infrastructure they already paid for once.

---

# Phase 3 — Grinding + Fresh Territory (Sarasota, Panama City, Naples, Fort Pierce)

## 14. RC Fitness (Sarasota) — RC Evans
**The problem:** Real domain, but never finished — the social media icons on the site literally link to Wix's own generic template pages (facebook.com/wix, twitter.com/wix), not RC's actual accounts. There's also an unedited iPhone photo filename left in as an image ("FullSizeRender.jpg"). Classic "paid for a template, never went back to finish it" signal.
**Approach:** Faith-forward branding ("Faith · Family · Fitness"), niche of training adults over 50 — a values-aligned, respectful tone will land better than a hard-sell one. The specific detail (social links going nowhere real) is a concrete, easy-to-verify hook.
**Contact:** rcefitness@gmail.com or (941) 600-8422

**Email:**
> **Subject:** A small thing on the RC Fitness website
>
> Hi RC,
>
> I came across RC Fitness and noticed something small but worth mentioning: the social media icons on your website actually link out to generic placeholder pages, not your real Facebook or Instagram. It looks like the template was never fully finished after it was set up.
>
> Put together a quick demo of a cleaned-up version: [demo link]
>
> No pressure — just wanted you to know, since most visitors wouldn't catch it themselves. Happy to help fix it up properly if useful.
>
> [Your name]

---

## 15. Sarasota Fitness Studio — Michael Lenza
**The problem:** Otherwise a real, decent site — but it has a live, publicly indexed blog post literally titled "Blog Post Title Four," an unedited placeholder that was never replaced with real content.
**Approach:** 15+ years in business, personal brand built on expertise (anatomy/kinesiology, licensed massage therapist) — frame this as a quick, low-effort fix rather than a full rebuild, since the rest of the site is fine. That keeps the ask small and easy to say yes to.
**Contact:** michael@sarasotafitnessstudio.com or (941) 894-2596

**Email:**
> **Subject:** Quick thing on the Sarasota Fitness Studio blog
>
> Hi Michael,
>
> Your site is in good shape overall, but I noticed one of your blog posts is still showing its placeholder title — "Blog Post Title Four" — live and public. Easy miss, but worth fixing since it's the kind of thing that undercuts the professional impression the rest of the site gives.
>
> Happy to help clean that up, or take a broader look at the site if you're interested: [demo link]
>
> [Your name]

---

## 16. Panama City Collective Fitness — Sarah Homestead (site creator/owner)
**The problem:** Rebranded from "Panama City CrossFit" to "Panama City Collective Fitness," but several internal navigation links and the contact email still point to the old name/domain (panamacitycrossfit.com, Panamacitycrossfit@gmail.com). The rebrand was never fully carried through the site.
**Approach:** Community-first tone ("strength through community") — frame this as tying up loose ends on a rebrand they already invested in, not starting over.
**Contact:** Panamacitycrossfit@gmail.com or (850) 640-1194

**Email:**
> **Subject:** A few loose ends from your rebrand
>
> Hi there,
>
> Noticed Panama City Collective Fitness's website still has a few leftover pieces from the old "Panama City CrossFit" name — a few nav links and the contact email still point to the old domain. Since you've already done the hard part (the actual rebrand), this is just about making the site match it.
>
> Put together a quick demo of a fully updated version: [demo link]
>
> Let me know if that'd be helpful.
>
> [Your name]

---

## 17. Odin Fitness (Naples) — new ownership, owner name unconfirmed
**The problem:** No website at all — recently changed ownership (LLC formed Dec 2025), currently just Snapchat/Yelp/Instagram listings. Reviews confirm members are happy with the new ownership's upgrades, but there's no web presence to match.
**Approach:** New-ownership framing works well here, same logic as The DAM Gym — they're already reinvesting in the place, a website is a natural next step alongside new equipment.
**Contact:** No email found — call (239) 331-7727 or DM via Instagram (@odin_fitness or @odin.fit.gear).

**Email (for phone/Instagram, given no email found):**
> Hi — saw Odin Fitness has new ownership and members are loving the upgrades. Noticed there's no website yet though, just social pages. Put together a quick demo of what one could look like: [demo link]. Happy to chat if useful.

---

## 18. Live Well Fitness Center (Fort Pierce) — Nicholas Burgos
**The problem:** No website — just Facebook and a Club Automation booking page. Note: Sunbiz shows this LLC as administratively dissolved (Sept 2025) — confirm the business is still actively operating before reaching out.
**Approach:** Community/challenge-based branding (5-week transformation challenges, inclusive of SilverSneakers members) — warm, results-focused framing fits well.
**Contact:** Livewellfitness5@gmail.com or (772) 807-0414

**Email:**
> **Subject:** A website for Live Well Fitness Center
>
> Hi Nicholas,
>
> Came across Live Well Fitness Center — the 5-week challenge results people are posting are great. Noticed there's no website though, just Facebook and the booking page.
>
> Put together a quick demo of what a simple site could look like: [demo link]
>
> Would help new folks in Fort Pierce find you and see those results before ever walking in. Let me know if you'd like to talk it through.
>
> [Your name]



Covers: Martinez Gym (Palm Bay), Debs Gym (Lakeland).

---

## 1. Martinez Gym (Palm Bay)
**The problem:** The website is a completely unedited free WordPress demo theme — the footer still literally credits "Martial Arts WordPress Theme By Ovation Themes." The "Home" nav link points to a broken staging subdomain (martinezgym.effexhost.com) instead of the live site. Social media icons link to generic placeholder pages (twitter.com/, linkedin.com/, instagram.com/ — no actual handles). All page content is unedited theme boilerplate.
**The story:** This gym is a memorial tribute — established in honor of Daniel Martinez, a lawyer and boxer who passed away, run for the community he cared about. Boxing classes for ages 6-100.
**Approach:** Handle this one with real care given the memorial context — lead with respect for what the gym represents, not just the technical issue. The broken site actually undercuts a meaningful story, which is a genuine, sincere reason to want it fixed.
**Contact:** Office@martinezgym.fit or (321) 419-8943

**Email:**
> **Subject:** Something about the Martinez Gym website
>
> Hi there,
>
> I came across Martinez Gym and read about the story behind it — what a meaningful tribute to Daniel. I noticed the current website is still running on an unedited template (the footer even credits the theme name), and a few links point to broken or placeholder pages instead of your real content.
>
> Given what this gym represents, it felt worth reaching out — a site that actually reflects the story would do it more justice. Put together a quick demo of what an updated version could look like: [demo link]
>
> No pressure at all — just wanted you to know. Happy to help if it's useful.
>
> [Your name]

---

## 2. Debs Gym (Lakeland)
**The problem:** Real, functioning site — but the copyright footer literally reads "Copyright © 2016 Debs Gym: House of Perfection." It hasn't been touched in roughly a decade. Some listed trainers/programs may no longer be current given how long it's been.
**The story:** 16,000 sq ft, 24/7 facility, owned by Debbie Callahan — an IFBB Pro Judge with 30+ years in the industry. Reviews are excellent and the gym is clearly thriving in person; the website just hasn't kept pace.
**Approach:** This is a "the business has grown, the site hasn't" pitch — similar to Sharper Edge Fitness from an earlier batch. Respectful of her expertise and long track record; frame the update as matching the site to the caliber of the gym, not fixing something broken.
**Contact:** (863) 683-9300 — no email found directly; try calling or a Facebook message.

**Email/message:**
> Hi Debbie — came across Debs Gym: House of Perfection, and it's clear how much of an institution it's become in Lakeland. Noticed the website's copyright footer still says 2016 though, so it hasn't been updated in quite a while. Put together a quick demo of what a refreshed version could look like: [demo link]. No pressure, just thought it was worth mentioning given how well-regarded the gym is.

---

## Suggested order
1. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
2. **Martinez Gym** — meaningful story, but handle with a gentler, more personal touch given the memorial context

---

## 3. Fitness 31 (Titusville)
**The problem:** No real website — just Facebook, ClassPass, and directory listings. It's a women-focused personal training studio (group classes, 1:1, suspension training) built around a "safe space" mission for busy moms.
**Approach:** The mission-driven framing (safety, comfort, combating fitness fears/insecurities) is the hook — a simple site could reinforce that message and make it easier for new women to find and trust the studio before ever walking in.
**Contact:** fitness.thirtyone@gmail.com or (321) 544-6173

**Email:**
> **Subject:** A website for Fitness 31?
>
> Hi there,
>
> I came across Fitness 31 and love the mission — building a safe, supportive space specifically for women. Noticed there's no website yet though, just Facebook and directory listings.
>
> A simple site could help new members find you and get a feel for that mission before their first class. Put together a quick demo of what one could look like: [demo link]
>
> No pressure — just wanted you to see it. Happy to help if it's useful.
>
> [Your name]

---

## Updated suggested order (all 3 from this continued session)
1. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
2. **Fitness 31** — clear mission-driven angle, easy yes
3. **Martinez Gym** — meaningful story, handle with a gentler, more personal touch

---

## 4. NUMA Speed Elite (Gainesville) — Tim Montgomery (owner, Olympic Gold Medalist)
**The problem:** The business's own domain (numaspeedelite.com) is now pointing to a broken, unfinished web app deployment — visitors see a completely blank page reading only "You need to enable JavaScript to run this app." Multiple major listings (Yelp, ClassPass, WellnessLiving, Facebook) still direct people to this domain as the official site, so anyone clicking through from those sources hits a dead end.
**The story:** A 13-year Gainesville institution, owned by a former Olympic Gold Medalist and World Record holder, with clients including current and former University of Florida athletes and NFL/MLB players. This is a real, credible, well-known brand — currently showing nothing at all online.
**Approach:** High-credibility owner, real prestige to lean on — the pitch here isn't "you need a website," it's "your current site is actively broken and costing you first impressions with people who are actively trying to find you right now." Concrete and easy to demonstrate (just send the broken link).
**Contact:** numaeliteoffice@gmail.com or (352) 262-7573

**Email:**
> **Subject:** Your website is currently showing a blank page
>
> Hi there,
>
> I was looking into NUMA Speed Elite and tried visiting your website — it's currently showing a completely blank page to visitors (just a technical error message, no content at all). Multiple places that link to you — Yelp, ClassPass, WellnessLiving — all point people to this same broken page.
>
> Given NUMA's reputation in Gainesville, that's a real first impression being lost. Put together a quick demo of what a working version could look like: [demo link]
>
> Happy to help get this fixed properly. Let me know if useful.
>
> [Your name]

---

## Final suggested order (all 4 from this continued session)
1. **NUMA Speed Elite** — urgent, concrete technical problem, credible/high-profile owner
2. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
3. **Fitness 31** — clear mission-driven angle, easy yes
4. **Martinez Gym** — meaningful story, handle with a gentler, more personal touch

---

## 5. Elite Body Fitness & Nutrition (Apopka) — Mark & Tracey Lucky
**The problem:** Same core issue as NUMA — the site's metadata is set to `noindex`, meaning Google is blocked from showing it in search results at all. Compounding it: the copyright footer reads "2019" (6 years stale) and the contact email embedded in the site itself is an old, likely-abandoned Road Runner address (elitebody@cfl.rr.com) rather than the Gmail they actually use now.
**The story:** A genuinely long-running, well-loved family business — husband-and-wife owned since 2004, faith-centered branding, strong reviews. The site clearly hasn't been touched in years even though the business itself is thriving.
**Approach:** Similar to NUMA — concrete, demonstrable technical problem (their site is invisible to Google searches), not a subjective design critique. Respectful, faith-aligned tone given their branding.
**Contact:** elitebodyapopka@gmail.com or (407) 880-2066

**Email:**
> **Subject:** Your website isn't showing up in Google search
>
> Hi Mark and Tracey,
>
> I came across Elite Body Fitness & Nutrition and wanted to flag something technical: your website is currently set up to block Google from showing it in search results. So even though the site itself looks fine, nobody searching "gym Apopka" or "personal training Apopka" would ever find it there.
>
> Given how long you've been established (since 2004!) and how strong your reviews are, that felt worth mentioning. Put together a quick demo of a refreshed version: [demo link]
>
> Happy to help get the technical piece fixed properly too. Let me know if useful.
>
> [Your name]

---

## Final suggested order (all 5 from this continued session)
1. **NUMA Speed Elite** — urgent, concrete technical problem (blank page), credible/high-profile owner
2. **Elite Body Fitness & Nutrition** — same noindex issue, long-established, warm faith-aligned tone
3. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
4. **Fitness 31** — clear mission-driven angle, easy yes
5. **Martinez Gym** — meaningful story, handle with a gentler, more personal touch

---

## 6. DeLand Fitness Studio (DeLand) — Butch McCowan & Max Aubry
**The problem:** The site has real content, but the browser tab title still reads "Mysite" — Wix's generic default page title, never renamed. A small detail, but a genuine sign the site was set up quickly and never fully finished — the kind of thing a business owner would never notice themselves since it only shows in the browser tab.
**Approach:** Kickboxing/MMA-focused, two co-owners, real track record (reviews going back to 2018). Frame as a quick, low-effort polish rather than a rebuild — the content itself is fine, it's the finishing touches that were missed.
**Contact:** No email found — call Butch at (386) 717-5822 or Max at (386) 402-6982.

**Message:**
> Hi — came across DeLand Fitness Studio. Small thing I noticed: your website's browser tab still shows the default "Mysite" title instead of your actual business name — an easy miss, but the kind of detail that affects how professional the site reads. Happy to help polish that up, or take a broader look if useful: [demo link]

---

## Final suggested order (all 6 from this continued session)
1. **NUMA Speed Elite** — urgent, concrete technical problem (blank page), credible/high-profile owner
2. **Elite Body Fitness & Nutrition** — same noindex issue, long-established, warm faith-aligned tone
3. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
4. **Fitness 31** — clear mission-driven angle, easy yes
5. **DeLand Fitness Studio** — small, low-effort fix, easy yes
6. **Martinez Gym** — meaningful story, handle with a gentler, more personal touch

---

## 6. Hammer Time Fitness (New Port Richey) — Mark & Christine
**The problem:** Real, functioning site — but the copyright footer reads "Copyright © 2009," a full 16+ years stale, despite the business being active and well-loved (18 years running, faith-centered branding, "Fitness, Faith and Food").
**Approach:** Faith-aligned tone matches theirs directly. Frame as "the site hasn't kept pace with how long you've been trusted in this community" — a long-tenure, high-loyalty business deserves a site that reflects it.
**Contact:** (727) 916-1655 — no email found; call or Facebook message.

**Message:**
> Hi Mark and Christine — came across Hammer Time Fitness and it's clear how much trust you've built over 18 years. Noticed your website's copyright footer still says 2009 though — might be worth a refresh to match where the business is today. Put together a quick demo: [demo link]. No pressure, just wanted you to see it.

---

## Final suggested order (all 7 from this session)
1. **NUMA Speed Elite** — urgent, concrete technical problem (blank page), credible/high-profile owner
2. **Elite Body Fitness & Nutrition** — same noindex issue, long-established, warm faith-aligned tone
3. **Hammer Time Fitness** — 16-year stale site, established, faith-aligned tone
4. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
5. **Fitness 31** — clear mission-driven angle, easy yes
6. **Martinez Gym** — meaningful story, handle with a gentler, more personal touch
7. **DeLand Fitness Studio** — small, low-effort fix (unrenamed browser tab)

---

## 7. DeLand Fitness Studio (DeLand) — Butch McCowan & Max Aubry
**The problem:** Real site with real content (kickboxing, MMA, personal training) — but the browser tab title still reads the generic default "Mysite," never renamed from the site builder's placeholder. A small, easy-to-fix detail, but visible in every open tab and bookmark.
**Approach:** Low-effort, quick-fix framing — this is a five-minute fix pitch, not a full rebuild, which makes it an easy yes.
**Contact:** (386) 717-5822 — no email found; call or Facebook message.

**Message:**
> Hi Butch and Max — noticed DeLand Fitness Studio's website still shows "Mysite" as the browser tab title, which is just a site-builder default that never got renamed. Small thing, but it shows up every time someone has your site open. Happy to help fix that and take a broader look if useful: [demo link]

---

## 8. Strive Athletic Club (Wesley Chapel) — John Passafume
**The problem:** The site's actual homepage (striveathleticclub.com) is currently down — it shows a hosting-provider message about reactivating the account and updating payment information, not the gym's real content at all.
**Flag before reaching out:** Signals on current operating status are mixed — Nextdoor calls them a "Neighborhood Favorite" in both 2020 and 2022 (a good sign), but one Yelp listing is tagged "CLOSED" (dated from a stale 2014 snapshot, likely unreliable) and Sunbiz shows an LLC under this name administratively dissolved back in 2019. Worth a quick call to confirm they're still operating before sending outreach.
**Approach:** If confirmed active — this is a very direct, easy pitch: their own site is telling visitors it's suspended for non-payment. That's about as concrete and undeniable a problem as it gets, self-branded as "the #1 gym in Wesley Chapel."
**Contact:** (813) 428-6973 — no email found; call directly.

**Message:**
> Hi John — I tried visiting Strive Athletic Club's website and it's currently showing a "reactivate your account" message instead of your actual site — looks like the hosting subscription lapsed. Wanted to flag it since anyone searching for you right now is hitting that page instead of real content. Put together a quick demo of a working version: [demo link]. Happy to help get it back up properly.

---

## Final suggested order (all 8 from this session)
1. **Strive Athletic Club** — site is literally down right now, most urgent (confirm still open first)
2. **NUMA Speed Elite** — urgent, concrete technical problem (blank page), credible/high-profile owner
3. **Elite Body Fitness & Nutrition** — same noindex issue, long-established, warm faith-aligned tone
4. **Hammer Time Fitness** — 16-year stale site, established, faith-aligned tone
5. **Debs Gym** — established owner, thriving business, straightforward "modernize" pitch
6. **Fitness 31** — clear mission-driven angle, easy yes
7. **Martinez Gym** — meaningful story, handle with a gentler, more personal touch
8. **DeLand Fitness Studio** — small, low-effort fix (unrenamed browser tab)



Covers leads that were added to the master list but never got a full write-up: Union Family Fitness, Forward Fitness, North Florida Fitness, S&J Downtown Athletic Club, Prime Performance Club, Body By DJ Studios, Champion Fitness, Barnyard Community Fitness.

---

## 1. Union Family Fitness (Lake Butler) — Jason & Nancy Johns
**The problem:** No dedicated website — only Instagram and Facebook.
**Note:** The contact email traces to a church pastor address (Fbclbpastor@windstream.net), suggesting this may be a church-affiliated program rather than a purely independent business. Worth knowing going in, though it doesn't change the pitch much — a website still helps either way.
**Approach:** Community-first framing fits well given the likely church tie.
**Contact:** (386) 433-0451 — no confirmed direct email; recommend Facebook message or call.

**Message:**
> Hi there — came across Union Family Fitness in Lake Butler. Noticed there's no dedicated website, just Instagram/Facebook. Put together a quick demo of what one could look like: [demo link]. Happy to help if useful.

---

## 2. Forward Fitness (Cross City) — Karen VanAernam
**The problem:** No dedicated website — just Facebook and a WellnessLiving listing.
**The story:** A women's fitness studio built around a supportive, community-driven space.
**Approach:** Warm, mission-aligned tone (by women, for women) fits their branding.
**Contact:** forwardfitnessstudio@gmail.com or (352) 356-0304

**Message:**
> Hi Karen — came across Forward Fitness, a great women's fitness studio in Cross City. Noticed there's no dedicated website, just Facebook and a WellnessLiving listing. Quick demo of what one could look like: [demo link]. Happy to help if useful.

---

## 3. North Florida Fitness (Starke) — owner unconfirmed
**The problem:** No real website — just Facebook/Instagram and a third-party GymMaster signup portal.
**The story:** Recently opened, extended hours (4am-11pm), $10 day pass, strong early reviews ("feels like family").
**Approach:** New-business framing — get a real site up while they're still building their base.
**Contact:** (904) 454-1471 — no email found; call directly.

**Message:**
> Hi there — came across North Florida Fitness in Starke. Noticed there's no dedicated website, just Facebook/Instagram and a signup portal. Quick demo of what one could look like: [demo link]. Happy to help if useful.

---

## 4. S&J Downtown Athletic Club (Starke) — owner unconfirmed
**The problem:** No real website — just a free Google Business Site placeholder and directory listings, no own domain.
**The story:** 24/7 gym with personal training and supplements available.
**Approach:** Straightforward — a free Google placeholder page reads as unfinished, easy contrast to draw.
**Contact:** (904) 214-6110 — no email found; call directly.

**Message:**
> Hi there — came across S&J Downtown Athletic Club, 24/7 gym in Starke. Noticed there's no real website, just a free Google placeholder page. Quick demo of what a real one could look like: [demo link]. Happy to help if useful.

---

## 5. Prime Performance Club (Wildwood) — owner unconfirmed
**The problem:** No dedicated website — Facebook/Instagram and an unclaimed WellnessLiving listing.
**The story:** Brand-new private training facility near The Villages, offering 1:1, group training, and assisted stretching.
**Approach:** New-business framing, similar to North Florida Fitness — establish a real web presence early.
**Contact:** Primeperformanceclub@outlook.com or (352) 303-8984

**Message:**
> Hi — congrats on the new facility! Noticed there's no website yet, just Facebook/Instagram and an unclaimed WellnessLiving listing. Put together a quick demo of what one could look like: [demo link]. Would help new clients in the Wildwood/Villages area find you as you're getting started. Happy to chat if useful.

---

## 6. Body By DJ Studios (Dunedin) — Derrick Evans
**The problem:** No dedicated website — only a TeamUp booking page and Instagram, no own domain.
**The story:** Boutique-style personal training studio in downtown Dunedin.
**Approach:** Straightforward, practical — boutique studio owners often run entirely on booking platforms and haven't considered a standalone site.
**Contact:** (727) 282-7561 — no email found; call or Instagram.

**Message:**
> Hi Derrick — came across Body By DJ Studios in downtown Dunedin. Noticed there's no dedicated website, just a booking page and Instagram. Put together a quick demo of what one could look like: [demo link]. Happy to chat if useful.

---

## 7. Champion Fitness (Madison) — Chase Knight
**The problem:** No dedicated website — Facebook and a few directory listings (Birdeye, Chamber of Commerce, Wellhub), no own domain.
**The story:** Family-friendly gym offering yoga, spin, and kids' karate for all ages.
**Approach:** Family-first framing fits the range of programs they offer.
**Contact:** (850) 779-7280 — no email found; call directly.

**Message:**
> Hi Chase — came across Champion Fitness in Madison. Noticed there's no dedicated website, just Facebook and a few directory listings. With yoga, spin, and kids' karate on offer, a simple site could help new families find you before ever walking in. Quick demo: [demo link]. Happy to chat if useful.

---

## 8. Barnyard Community Fitness (Perry) — owner unconfirmed
**The problem:** No dedicated website — Facebook/Instagram and an unclaimed directory listing.
**The story:** CrossFit-style community gym with a "no egos, just hard work" ethos.
**Approach:** Community/no-frills framing matches their branding directly.
**Contact:** (386) 249-1202 / (850) 843-4182 — no email found; call directly.

**Message:**
> Hi there — came across Barnyard Community Fitness in Perry, love the "no egos, just hard work" community vibe. Noticed there's no dedicated website, just Facebook/Instagram. Quick demo of what one could look like: [demo link]. Happy to help if useful.



Panhandle small-town push: Chipley, Blountstown, Monticello, Defuniak Springs, and Bristol.

---

## 1. Neighborhood Fitness (Chipley)
**The problem:** No real website, just Facebook and a GymMaster membership portal.
**Note:** Has a sister location, Graceville Fitness, sharing the same phone number and portal — same owner, so treat as one relationship, not two separate leads.
**Contact:** (850) 209-7153

**Message:**
> Hi there — came across Neighborhood Fitness in Chipley. Noticed there's no dedicated website, just Facebook and a membership portal. Put together a quick demo of what one could look like: [demo link]. Happy to help if useful.

---

## 2. #GymLife (Blountstown)
**The problem:** No real website. The domain listed on their Chamber of Commerce page (gymlife.com) is actually an unrelated California apparel brand — a mismatch, not their real site.
**Contact:** (850) 508-3534

**Message:**
> Hi there — came across #GymLife in Blountstown, love that you've got a kids' playroom and a racquetball court alongside the gym. Noticed there's no real website — the domain on your Chamber listing actually points to an unrelated clothing brand. Put together a quick demo of a real one: [demo link]. Happy to help if useful.

---

## 3. B Fitness Monticello
**The problem:** No own website, just Facebook/Instagram. (Note: there's a separate "B Fitness Venice" with its own real site — different business, same name pattern, don't confuse the two.)
**Contact:** (850) 332-1551 — owner referenced as "Joe" in reviews.

**Message:**
> Hi Joe — came across B Fitness in Monticello, sounds like a great community spot. Noticed there's no website, just social media. Put together a quick demo: [demo link]. Happy to help if useful.

---

## 4. THE GYM / Kickin It Fitness (Defuniak Springs)
**The problem:** No real website — only a third-party class-booking listing (Sawyer). No phone or email found either.
**The story:** Military-owned, offers boxing/kickboxing/dance/yoga, strong women's-empowerment branding. Owner referenced as Stephen "Murph" Murphy.
**Contact:** Not found — recommend an in-person visit or searching Facebook directly for "Kickin It Fitness Defuniak Springs" to message them.

---

## 5. Down Range Fitness (Bristol)
**The problem:** No website — just Facebook. Currently mid-transition: new owner Samantha Buckhalt recently took over from her father, Sidney Johnson. Payments are cash/check/Venmo only — a very manually-run operation.
**Approach:** New-ownership framing works well here (like The DAM Gym earlier) — she's already updating equipment, a website is a natural next step.
**Contact:** (850) 545-2788

**Message:**
> Hi Samantha — congrats on taking over Down Range Fitness! Since you're already updating equipment, this seemed like a good time to mention: there's no website yet, just Facebook. Put together a quick demo: [demo link]. Happy to help if useful.

---

## 6. 180 Fitness (Bristol)
**The problem:** No website found anywhere — small, well-loved 24/7 gym.
**Contact:** (850) 643-2144

**Message:**
> Hi there — came across 180 Fitness in Bristol, sounds like a great low-key spot to train. Noticed there's no website. Put together a quick demo: [demo link]. Happy to help if useful.

---

## Honest note on today's count
You asked for at least 12 — after checking roughly 35 businesses across 15 small Panhandle towns, 6 genuinely verified leads is where it landed (one more, Graceville Fitness, turned out to be the same operator as Neighborhood Fitness, not a separate lead). This is a solid, well-verified batch, just short of the number requested — padding it further would have meant relaxing verification, which isn't the trade worth making.



---

## Garcia's Boxing Gym (Clewiston)
**The problem:** No real website found — only a directory listing (boxinggyms.net), no own domain.
**The story:** Dedicated boxing gym offering a positive, supportive environment for all ages, including a kids' program.
**Approach:** Straightforward — boxing/combat-sport gyms often run purely on word of mouth and social media, so a simple site framing could feel like a genuine upgrade rather than a critique.
**Contact:** (231) 342-7552 — no email found; call directly.

**Message:**
> Hi there — came across Garcia's Boxing Gym in Clewiston. Noticed there's no real website, just a directory listing. Put together a quick demo of what one could look like: [demo link]. Would help families searching for a boxing program for their kids find you more easily. Happy to help if useful.

---

## Country Strong Gym (Mayo)
**The problem:** No real website — just Facebook and third-party directory aggregators (Yellow Pages, Wellhub).
**The story:** Family-run business offering 20+ weekly classes (including "Weights and Worship"), judgment-free atmosphere, strong local reputation (100% recommend on Facebook).
**Approach:** Warm, community/faith-aligned tone fits their branding well.
**Contact:** thecountrystronggymmayo@gmail.com or (386) 854-0115 — owner referenced as Melissa in reviews.

**Message:**
> Hi Melissa — came across Country Strong Gym in Mayo, love that you offer 20+ classes and such a welcoming atmosphere. Noticed there's no real website yet, just Facebook. Put together a quick demo of what one could look like: [demo link]. Happy to help if useful.

---

## Dicks Power House (Live Oak)
**The problem:** No real website — just Facebook and a GymMaster membership portal.
**The story:** 24/7 gym with tanning beds, easy online sign-up, well-loved for its clean, old-school atmosphere.
**Approach:** Practical, straightforward pitch — a real site could reinforce the "easy 24/7 sign-up" convenience angle they already lead with.
**Contact:** (386) 623-9098 — no email found; call directly.

**Message:**
> Hi there — came across Dicks Power House in Live Oak, sounds like a great 24/7 spot. Noticed there's no real website, just Facebook and the membership portal. Put together a quick demo: [demo link]. Happy to help if useful.



---

## Gladiator Fitness (Crescent City) — Daniel Aragon
**The problem:** Real domain (gladiatorfitnessgym.com), but the "meet the team" section still shows raw, unedited placeholder instruction text repeated four times: "Describe the team member here. Write a brief description of their role and responsibilities..." It was never actually filled in with real content.
**The story:** Family-owned, opened fairly recently, offers personalized training and nutrition guidance in a private setting.
**Approach:** Straightforward, practical framing — the site exists and looks fine at first glance, but the placeholder text undercuts the "personalized" pitch they're making. Easy, concrete fix.
**Contact:** elitedaniel2017@gmail.com or (386) 698-2533

**Message:**
> Hi Daniel — came across Gladiator Fitness. Noticed your site's team section still has the placeholder text from the template ("Describe the team member here...") rather than real bios. Easy thing to miss, but worth fixing since it's the first thing new visitors see. Put together a quick demo of a cleaned-up version: [demo link]. Happy to help if useful.

---

## The Elite Gym LLC (Bunnell) — Shelby
**The problem:** No real website at all — just Facebook and Sunbiz/directory listings.
**The story:** Private, family-owned gym with limited membership (intentionally not overcrowded), offering personal training and youth athlete classes.
**Approach:** The "exclusive, limited-membership" branding they already use ("Exclusive. Pristine. Elite.") is a strong hook — frame the site as reinforcing that positioning, not just filling a gap.
**Contact:** (386) 597-3016 — no email found; call or Facebook message.

**Message:**
> Hi Shelby — came across The Elite Gym in Bunnell, love the "Exclusive. Pristine. Elite." positioning. Noticed there's no website yet, just Facebook. A simple site could reinforce that same exclusive feel before someone even walks in. Put together a quick demo: [demo link]. Happy to help if useful.



---

## The SweatBox Gym (Fort Meade) — Pastor Andrea Camp
**The problem:** No real website — confirmed the domain that appears in search ("thesweatboxgym.com") actually belongs to a completely different, unrelated gym in Terre Haute, Indiana.
**The story:** Small, locally owned, downtown gym with personal training led by the owner, who's also a pastor.
**Approach:** Warm, community-first tone fits well given the pastor connection.
**Contact:** (863) 205-1262 — no email found; call directly.

**Message:**
> Hi Pastor Camp — came across The SweatBox Gym in downtown Fort Meade. Noticed there's no real website for the actual gym here (there's a similarly-named one in Indiana, but that's a different business). Put together a quick demo of what a real one could look like: [demo link]. Happy to help if useful.

---

## The Monster Factory (Lake Placid) — Sensei Jose Laguer
**The problem:** No real website — just Facebook and unclaimed directory/fighter-database listings (Yelp, Tapology).
**The story:** Family-owned Brazilian Jiu-Jitsu dojo, recently relocated after outgrowing its old space, run by Sensei Jose Laguer (3rd-degree black belt) and his wife Melissa. Teaches ages 3 to adult, including students with disabilities — a genuinely inclusive, community-rooted business with a strong local news feature already written about them.
**Approach:** Lean into the inclusive, family-first story — this is a business with real heart behind it, and the website should reflect that, not just list class times.
**Contact:** (863) 275-0615 — no email found; call or Facebook message.

**Message:**
> Hi Sensei Laguer — read about The Monster Factory's move to the new location and the story behind it, it's clear how much heart goes into what you and Melissa have built. Noticed there's no website yet, just Facebook. Put together a quick demo of what one could look like: [demo link]. Happy to help if useful.



---

## Kommunity Box Fit (Pahokee) — owner unconfirmed
**The problem:** No real website found anywhere. Even their Facebook page is currently restricted or unavailable to view publicly — so right now, this business has essentially zero reliable online presence at all.
**The story:** Family-owned boxing gym offering self-defense, weight loss, and boxing training for all ages. Reviews describe it as a genuine community anchor — "a great way to keep kids out of trouble," coaches who "treat you like family." One critical review mentions maintenance issues (roof leaks, cleanliness), which is worth being aware of but isn't the focus of the website pitch.
**Approach:** Community/family-first framing fits well given the reviews. Since even their Facebook is hard to find right now, the pitch can lean on "right now, there's almost no way for someone searching online to find you at all" — a strong, simple hook.
**Contact:** (561) 692-1506 — no email found; call directly, or try visiting in person since Pahokee is a small town.

**Message:**
> Hi there — came across Kommunity Box Fit in Pahokee. Noticed there's no real website, and even your Facebook page is hard to find right now. Put together a quick demo of what a simple site could look like: [demo link]. Would help families in town find you more easily. Happy to help if useful.



---

## The Refinery Fitness (Palatka) — Dina
**The problem:** Real, polished, recent site (© 2024, active Calendly booking links, full navigation) — but it's set to `noindex`, blocking Google from showing it in search results at all. Same exact issue we found on NUMA Speed Elite and Elite Body Fitness & Nutrition. Anyone searching "personal training Palatka" right now would never find this site, no matter how good it is.
**Flag before reaching out:** One directory (Birdeye) lists the business as "temporarily closed" — but the site itself looks clearly active, so this is likely just a stale listing rather than an actual closure. Worth a quick confirm before sending, just in case.
**The story:** A "NYC-style boutique fitness studio" brought to downtown Palatka — personal training, semi-private sessions, nutrition coaching, and virtual programming. Reviews are glowing ("doesn't even look like we're in Palatka anymore").
**Approach:** Technical-credibility framing, same as NUMA — this isn't a design critique, it's flagging something invisible that's actively costing them visibility.
**Contact:** refineryfitness@yahoo.com or (386) 937-2358

**Email:**
> **Subject:** Your website is invisible to Google search
>
> Hi Dina,
>
> I came across The Refinery Fitness and love the concept — a boutique studio like yours in downtown Palatka. I checked your website and noticed something behind the scenes: it's currently configured to block search engines from indexing it. That means even though the site itself looks great, nobody searching "personal training Palatka" would ever find it in Google results.
>
> Happy to point you to exactly what's causing it, or help get it fixed. Also put together a quick demo of an updated version if useful: [demo link]
>
> No pressure — just thought you'd want to know.
>
> [Your name]



---

## Nomads Martial Arts (Melrose) — owner unconfirmed
**The problem:** Real domain (nomadsmartialarts.com), but genuinely unfinished — the About section still shows raw, unedited template placeholder text: *"I'm your About section. Click to edit and tell your visitors more about your philosophy. What are the goals of your school?"* This is live and publicly visible. On top of that, the copyright footer reads "© 2018" — seven years stale.
**The story:** A traditional Okinawan Goju-Ryu karate school housed in a building with real local history (formerly a hardware store, then a hair salon) in small-town Melrose. Offers self-defense, boxing, and kickboxing for ages 5 to 65, no contracts required. Small but well-regarded (5.0 rating, though only 3 reviews).
**Approach:** Two concrete, easy-to-verify issues (placeholder text + stale date) make this a low-pressure, practical pitch — you're not questioning their business, just pointing out two things that clearly got missed when the site was first built and never touched since.
**Contact:** (352) 478-5115 — no email found; call or Facebook message.

**Message:**
> Hi there — came across Nomads Martial Arts. Noticed a couple of things on the website: the About section still shows the placeholder text from the template ("Click to edit and tell your visitors more about your philosophy..."), and the copyright footer says 2018. Easy things to miss, but worth fixing since they're the first thing new visitors see. Put together a quick demo of a cleaned-up version: [demo link]. Happy to help if useful.



Note: Strive Athletic Club was found in the previous turn (Wesley Chapel search), not this one — it's already in the tracker from before. Only Iron Anchor Gym is genuinely new from this search round.

## Iron Anchor Gym (Leesburg) — owner unconfirmed
**The problem:** No website at all — genuinely brand-new business (confirmed via local Facebook group "grand opening" posts), only 1 Google review, no phone listed.
**Approach:** Very new business — frame as "get ahead of it while you're still building your member base," not "you've been missing this."
**Contact:** No phone or email found. Address: 10601 US-441 Ste C5, Leesburg, FL 34788. Best path is likely an in-person visit or a message in the local Facebook group where their opening was announced.

---

## Method note for future sessions
Reviewed what's worked across the whole pipeline: businesses with 30+ Google reviews almost always already have a real website. Going forward, prioritize checking listings with under 20 reviews or no phone number first — that's where the actual hit rate lives. Sunbiz.org is reliable for verifying a specific business's owner/status once found elsewhere, but not for browsing/discovering new candidates directly (its search doesn't support location/date filtering cleanly).



Found using the refined method: skip anything with 30+ Google reviews, prioritize sparse-review listings (under 20), accept phone-only contact where no email surfaces.

## CTX Barbell (Longwood) — owner unconfirmed
**The problem:** No real website — just Instagram (@ctxbarbellorlando) and third-party gym-directory listings (Waze, Mammoth Strength). A serious powerlifting facility with specialty equipment (monolift, reverse hyper, competition bench) and zero web presence of their own.
**Approach:** Equipment-and-competition-focused pitch — powerlifters searching for a "meet prep" gym in the area would be a strong audience a real site could actually capture.
**Contact:** (407) 575-9377 — no email found; call or Instagram DM.

**Message:**
> Hi — came across CTX Barbell, impressive equipment lineup for serious powerlifters. Noticed there's no website though, just Instagram. Put together a quick demo of what one could look like: [demo link]. Could help lifters searching for meet prep gyms in the area actually find you. Happy to chat if useful.

---

## Elite FitClub (Haines City) — Saray & Luis
**The problem:** No website found anywhere — started from the owner's garage, now a beloved small community studio, but has zero web presence beyond word of mouth.
**Approach:** Genuine, heartwarming origin story (started in a garage) — lean into that authenticity rather than a corporate pitch.
**Contact:** (863) 204-9663 — no email found; call directly.

**Message:**
> Hi Saray — heard about Elite FitClub starting from your garage and growing into what it is now, that's a great story. Noticed there's no website yet though. Put together a quick demo: [demo link]. Would help more people in Haines City find you. No pressure, just wanted you to see it.

---

## Method note
This batch used the enhanced approach: scanned ~8 cities in one pass, filtered by review count first (skip 30+), and accepted phone-only contact instead of digging for email on every lead. Faster per-lead time than the deep city-by-city method.


## Warehouse Gym (High Springs) — Bill & Steve
**The problem:** No real website — only Facebook, Instagram, and directory aggregator listings. Reviews explicitly mention that the listed phone number sometimes goes unanswered.
**The story:** Family-friendly gym, seniors welcome, coded 24/7 entry, full range of equipment.
**Approach:** Practical, straightforward pitch.
**Contact:** (386) 418-8161

**Message:**
> Hi Bill/Steve — came across Warehouse Gym in High Springs. Noticed there's no real website, just Facebook and some directory listings. Put together a quick demo: [demo link]. Would give people an easy way to see your hours and info without needing to call. Happy to help if useful.

---

## 8 Limbs MMA (Fort White) — owner unconfirmed
**The problem:** No real website found anywhere — every search result is an unrelated gym with the same name in another state.
**The story:** Local MMA training gym in the small community of Fort White.
**Contact:** (954) 806-3358

**Message:**
> Hi there — came across 8 Limbs MMA in Fort White. Noticed there's no website of your own — every search result actually points to unrelated gyms with the same name in other states. Put together a quick demo: [demo link]. Happy to help if useful.


## Elevate Fitness (Eustis) — Andrea & David Iturrino
**The problem:** Real domain but resolves to a completely blank page.
**Contact:** elevatefitnessfl@gmail.com or (321) 304-7011

**Message:**
> Hi Andrea and David — I came across Elevate Fitness and tried visiting your website — it's currently showing a completely blank page. Put together a quick demo: [demo link]. Happy to help get this fixed properly.

---

## Elevated Athletics (Groveland) — owner unconfirmed
**The problem:** No website found, only Facebook.
**Contact:** (407) 252-7070

**Message:**
> Hi there — came across Elevated Athletics in Groveland. Noticed there's no website. Put together a quick demo: [demo link]. Happy to help if useful.


## 1ElevenFitness (Bainbridge, GA) — Philip Dollar
**The problem:** No real website, only Facebook and a Mindbody booking link.
**Contact:** (949) 426-2562

**Message:**
> Hi Philip — came across 1ElevenFitness in downtown Bainbridge. Noticed there's no real website. Put together a quick demo: [demo link]. Happy to help if useful.

---

## USA Gym & Fitness Center (Andalusia, AL) — Darrell Barnett
**The problem:** Established 1997, no real website, only directory listings.
**Contact:** (334) 222-5828

**Message:**
> Hi Darrell — came across USA Gym & Fitness Center. Nearly 30 years in business, but noticed there's no real website. Put together a quick demo: [demo link]. Happy to help if useful.


## USA Gym & Fitness Center (Opp, AL) — owner unconfirmed
**The problem:** No real website - customer reviews literally ask for one and complain the phone/contact info doesn't work.
**Contact:** (334) 493-1212

**Message:**
> Hi there — I noticed a few reviews asking if there's a website to sign up on. Put together a quick demo: [demo link]. Happy to help if useful.

---

## Dillards Elite Fitness LLC (Opp, AL) — owner unconfirmed
**The problem:** No real website, listing shows "Website: facebook.com."
**Contact:** (334) 378-8735

**Message:**
> Hi there — came across Dillards Elite Fitness in Opp. Noticed there's no real website, just a Facebook page. Put together a quick demo: [demo link]. Happy to help if useful.
